<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="application/x-www-form-urlencoded">
</head>
<body>
	<!-- Please update your right sandbox url
		example : https://sonypayments01-tech-prtnr-eu03-dw.demandware.net/on/demandware.store/Sites-RefArch-Site/ja_JP/SonyPayment-ListenerSonyManageCard
	 -->
	<form action="<please-update-your-sandbox-url-here>" method="post" id="3DSecureForm">
            <input type="hidden" name="EncryptValue" value="<?php echo $_POST['EncryptValue']?>" />
    </form>
    <script>
        document.getElementById('3DSecureForm').submit();
    </script>
</body>

</html>